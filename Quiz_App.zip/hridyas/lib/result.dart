import 'package:flutter/material.dart';


class Result extends StatelessWidget {
  final int resultScore;
  final Function resetHandler;

  Result(this.resultScore, this.resetHandler);

  String get resultPhrase {
    var resultText = "You did it";
    if (resultScore == 0) {
      resultText = """You need to know better
Your Score is 0/15""";
    } else if (resultScore == 5) {
      resultText = """Seems good!
Your Score is 5/15""";
    }
    else if (resultScore == 10) {
      resultText = """Pretty Nice
Your Score is 10/15""";
    }
    else {
      resultText = """Awesome! You know it well
Your Score is 15/15""";
    }

    return resultText;
  }

  @override
  Widget build(BuildContext context) {
    return  Center(
      child: Column(
      children: <Widget> [
        Container(
          width: 400.0,
        padding: EdgeInsets.only(top: 200.0),
        child: Text(
        resultPhrase,
    style: TextStyle(
    color: Colors.black,
    fontWeight: FontWeight.bold,
    fontSize: 40.0,
    ),
        textAlign: TextAlign.center,
    ),
        ),
        Container(
          width: 200.0,
        padding: EdgeInsets.only( top: 30.0),
        child: FlatButton(
          color: Colors.black,
          child: Text("Reset Quiz"),
          textColor: Colors.white,
          onPressed: resetHandler,
    )
        ),
        ],
      ),
    );
  }
}
