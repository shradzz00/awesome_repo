import 'package:flutter/material.dart';



class Answer extends StatelessWidget {
  final Function select;
  final String answerText;

  Answer(this.select, this.answerText);

  @override
  Widget build(BuildContext context) {
    return Container(
      width: double.infinity,
      child: RaisedButton(
        color: Colors.black,
        child: Text(answerText,
          style: TextStyle(
            color: Colors.white,
            fontWeight: FontWeight.bold,
          ),
        ), onPressed: select,
      ),
    );
  }
}

