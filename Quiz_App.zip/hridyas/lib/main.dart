import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';

import './quiz.dart';
import './result.dart';


void main() => runApp(MyApp());

class MyApp extends StatefulWidget {

  @override
  State<StatefulWidget> createState() {
    return _MyAppState();
  }
  }
class _MyAppState extends State<MyApp> {
  final _questions = const [
    {
      "questionText": "Which is the biggest Planet in our Solar System?",
      "answers":[
        { "text": "Mars", "score": 0},
        {"text": "Jupitor", "score": 5},
        {"text": "Venus", "score": 0},
        { "text":"Saturn", "score":0}],
    },
    {
      "questionText": "Name the galaxy to which our Solar System belongs",
      "answers":[
        { "text": "Andromeda", "score": 0},
        {"text": "Virgo A", "score": 0},
        {"text": "Megellanic Clouds", "score": 0},
        { "text":"Milky Way", "score":5}
        ],
    },
    {
      "questionText": "Which planet is nearer to Earth?",
      "answers":[
        {"text": "Uranus", "score": 0},
        {"text": "Saturn", "score": 0},
        {"text": "Mars", "score": 5},
        { "text":"Venus", "score":0}
        ],
    },
  ];

  var _questionIndex = 0;
  var _totalScore = 0;

  void _resetQuiz() {
    setState(() {
      _questionIndex = 0;
      _totalScore = 0;
    });
  }
  void _answerQuestion(int score) {

    _totalScore = _totalScore + score;


  setState(() {
  _questionIndex = _questionIndex + 1;
  });
    if (_questionIndex < _questions.length) {
    } else {

    }
  }
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      home: Scaffold(
        appBar: AppBar(
          backgroundColor: Colors.black,
          title: Text("My App",
              textAlign: TextAlign.center,
            style: TextStyle(
              color: Colors.white,
              fontWeight: FontWeight.bold,
            ),
          ),
        ),
        body: _questionIndex < _questions.length
            ? Quiz(
          answerQuestion: _answerQuestion,
          questionIndex: _questionIndex,
          questions: _questions,
        )
         : Result(_totalScore, _resetQuiz),
      ),
    );
  }
}
